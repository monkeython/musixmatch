============
album module
============

.. automodule:: musixmatch.album

   .. autoclass:: Album
      :show-inheritance:

   .. autoclass:: AlbumsCollection
      :show-inheritance:
      :members: fromArtist
