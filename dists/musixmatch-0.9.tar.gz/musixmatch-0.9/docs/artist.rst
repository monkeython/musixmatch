=============
artist module
=============

.. automodule:: musixmatch.artist

   .. autoclass:: Artist
      :show-inheritance:

   .. autoclass:: ArtistsCollection
      :show-inheritance:
      :members: fromSearch, fromChart
