=============
lyrics module
=============

.. automodule:: musixmatch.lyrics

   .. autoclass:: Lyrics
      :show-inheritance:
