===============
subtitle module
===============

.. automodule:: musixmatch.subtitle

   .. autoclass:: Subtitle
      :show-inheritance:
