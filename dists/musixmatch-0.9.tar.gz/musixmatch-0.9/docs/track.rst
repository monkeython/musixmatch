=============
track module
=============

.. automodule:: musixmatch.track

   .. autoclass:: Track
      :show-inheritance:
      :members: fromMatcher, get, postFeedback

   .. autoclass:: TracksCollection
      :show-inheritance:
      :members: fromAlbum, fromSearch, fromChart
